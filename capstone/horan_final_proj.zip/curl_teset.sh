curl -X POST -H "Content-Type: application/json" -d @to_predict_json.json http://localhost:5000/predict_lr
