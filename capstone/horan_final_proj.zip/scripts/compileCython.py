import sys, os

name = sys.argv[1]
code = sys.argv[2]

of = open("setup.py", "w")
of.write("""
#!/usr/bin/env python

from distutils.core import setup
from Cython.Build import cythonize
import numpy as np

setup(
   name = '""" + name + """',
   ext_modules = cythonize('""" + code + """'),
   include_dirs = [np.get_include()]
)
""")
of.close()

os.system("python setup.py build_ext --inplace")
