
import pickle
import numpy as np
import pandas as pd
from PIL import Image
import xgboost as xgb
from sklearn.cluster import KMeans
import colorFracs_v4 as cf4

models={}

#loads a presaved model into memory
def load_model(m_type):

    try:

        if m_type == 'logistic regression':
            models[m_type] = pickle.load(open('nColors_logreg.pickle','rb'))
        elif m_type == 'decision tree':
            models[m_type] = pickle.load(open('tree_depth1.pickle','rb'))
        elif m_type == 'xgboost':
            m=xgb.XGBClassifier()
            m.load_model('xgb_nColor.pickle')
            models[m_type] = m
        elif m_type == 'lr clust':
            models[m_type] = pickle.load(open('logreg_clust.pickle','rb'))
        elif m_type == 'rf clust':
            models[m_type] = pickle.load(open('rf_clust.pickle','rb'))
        elif m_type == 'xgb clust':
            m=xgb.XGBClassifier()
            m.load_model('xgbClust.pickle')
            models[m_type] = m
        elif m_type == 'transfer':
            models[m_type] = pd.read_pickle('transferLearningModel.pickle').loc[0]
        else:
            print('Invalid model type')

    except:
        print('Could not find model')

t_type={}
t_type['logistic regression'] = 'nColors'
t_type['decision tree'] = 'nColors'
t_type['xgboost'] = 'wrap_nColors'
t_type['lr clust'] = 'fracColors'
t_type['rf clust'] = 'fracColors'
t_type['xgb clust'] = 'wrap_fracColors'
t_type['transfer'] = 'repix'

#makes predictions on a model already loaded into memory
#if transform==True, then the data is first transformed according to the model type
#otherwise, the data is assumed to have been already transformed using transform_images
#if m_type == 'logistic regression' or 'decision tree', then data should be a list of images or an np array reshaped to (-1,1) of ncolors in each image, and the output is the probability that the cell in the image is infected with malaria predicted by the model
#if load ==True, then assume data is a list of image files to load and transform to make model predictions
def predict(m_type,data,transform=True, load=False):

    if load:
        transform = True
        data = [load_img(imfile) for imfile in data]

    data = data if transform == False else transform_images(t_type[m_type],data)

    model=''
    try:
        model = models[m_type]
    except:#if it fails, try loading model into memory first
        load_model(m_type)
        model = models[m_type]

    if m_type in ['logistic regression','decision tree', 'lr clust', 'rf clust']:
        return models[m_type].predict_proba(data)[:,1]
    elif m_type in ['xgboost', 'xgb clust']:
        return models[m_type].predict(data)
    else:
        print('Invalid model type')

#t_types:
#nColors: convert image to number of colors in the image
#wrap_nColors: convert image to number of colors and put in wrapper for xgb prediction
#wrap_nColorss_only: assumes nColors transformation has already been done and places in an xgb wrapper
#fracColors: clusters the image to 7 colors with KMeans, then calculates the fraction of each clustered color, sorting them, for input to the fraction clustered color models
#wrap_fracColors: does fracColors and wraps for xgb prediction
#wrap_fracColors_only: assumes fracColor is already done and just puts in wrapper for xgb
def transform_images(t_type,data):

    if t_type == 'nColors':
        nColors = np.zeros(len(data))
        for dex, im in enumerate(data):
            i = im#load_img(im)
            ishp = i.shape
            nColors[dex] = len(pd.DataFrame(i.reshape(ishp[0]*ishp[1],3)).drop_duplicates().index)#gets # of colors in image
        data = nColors.reshape(-1,1)
    elif t_type == 'wrap_nColors':
        data = xgb.DMatrix(transform_images('nColors',data)) #first convert to n colors, then wrap in an xgb DMatrix object
    elif t_type == 'wrap_nColors_only':
        data = xgb.DMatrix(data)
    elif t_type == 'fracColors':
        fracs=np.zeros(shape=(len(data),7))
        for i, im in enumerate(data):
            model = KMeans(n_clusters = 7, random_state = 42)
            shp = im.shape
            im1 = im.reshape(shp[0]*shp[1],3)
            cR = im1[:,0]
            cG = im1[:,1]
            cB = im1[:,2]
            model.fit(im1)
            fit_centers = model.cluster_centers_
            fit_labels = model.labels_
            imFracs = np.sort(cf4.colorFrac(im, fit_centers, cR, cG, cB, fit_labels, 7, 0))
            fracs[i] = imFracs
        data = fracs
    elif t_type == 'wrap_fracColors':
        data = xgb.DMatrix(transform_images('fracColors',data))
    elif t_type == 'wrap_fracColors_only':
        data = xgb.DMatrix(data)
    else:
        print('Invalid transformation type')

    return data

#loads an image from file
def load_img(imfile):
    img = Image.open(imfile)
    img.load()
    return np.asarray(img, dtype='int32')
    

def help():
    print("""
    Capstone Project Deliverable for Brandon Horan Springboard Machine Learning Engineering Carrer Track
    
    This project sought to model the Malaria Images dataset and determine whether an image of a cell was infected with malaria or not.  Included in this deliverable are a handful of models I developed which can be used to make predicions on images/data representing images.
    
    Available models to make predictions with:
    
    1. Number Colors: Logistic Regression, Decision Tree, XGBoost: 
        Input - Number of colors in an image

    2. Fraction Clustered Colors: Logistic Regression, Random Forest, XGBoost
        Input - Sorted Fraction of 7 cluster KMeans colors in each image
        
        
    How to use this deliverable:
        -Models may be loaded into memory using 'load_model'
        -Images may be loaded into memory using 'load_images'
        -Images may be transformed to model inputs using 'transform_images'
        -Predictions may be made on loaded images using 'predict'

    m_type legal values:
    'logistic regression'
    'decision tree'
        """)
