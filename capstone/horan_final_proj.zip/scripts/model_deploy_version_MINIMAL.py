
import pickle
import numpy as np
import pandas as pd

models={}

#loads a presaved model into memory
def load_model(m_type):

    try:

        if m_type == 'logistic regression':
            models[m_type] = pickle.load(open('nColors_logreg.pickle','rb'))
        elif m_type == 'decision tree':
            models[m_type] = pickle.load(open('tree_depth1.pickle','rb'))
        elif m_type == 'xgboost':
            models[m_type] = pickle.load(open('nColor_xgboostModel.pickle','rb'))
        elif m_type == 'lr clust':
            models[m_type] = pickle.load(open('logreg_clust.pickle','rb'))
        elif m_type == 'rf clust':
            models[m_type] = pickle.load(open('rf_clust.pickle','rb'))
        elif m_type == 'xgb clust':
            models[m_type] = pickle.load(open('xgb_clust.pickle','rb'))
        elif m_type == 'transfer':
            models[m_type] = pd.read_pickle('transferLearningModel.pickle').loc[0]
        else:
            print('Invalid model type')

    except:
        print('Could not find model')

t_type={}
t_type['logistic regression'] = 'nColors'
t_type['decision tree'] = 'nColors'
t_type['xgboost'] = 'wrap_nColors'
t_type['lr clust'] = 'fracColors'
t_type['rf clust'] = 'fracColors'
t_type['xgb clust'] = 'wrap_fracColors'
t_type['transfer'] = 'repix'

#makes predictions on a model already loaded into memory
#if transform==True, then the data is first transformed according to the model type
#otherwise, the data is assumed to have been already transformed using transform_images
#if m_type == 'logistic regression' or 'decision tree', then data should be a list of images or an np array reshaped to (-1,1) of ncolors in each image, and the output is the probability that the cell in the image is infected with malaria predicted by the model
def predict(m_type,data,transform=True):

    data = data if transform == False else transform_images(t_type[m_type],data)
    model=''
    try:
        model = models[m_type]
    except:#if it fails, try loading model into memory first
        load_model(m_type)
        model = models[m_type]

    if m_type in ['logistic regression','decision tree', 'lr clust', 'rf clust']:
        return models[m_type].predict_proba(data)[:,1]
    elif m_type in ['xgboost', 'xgb clust']:
        return models[m_type].predict(data)
    else:
        print('Invalid model type')

#t_types:
#nColors: convert image to number of colors in the image
#wrap_nColors: convert image to number of colors and put in wrapper for xgb prediction
#wrap_nColorss_only: assumes nColors transformation has already been done and places in an xgb wrapper
#fracColors: clusters the image to 7 colors with KMeans, then calculates the fraction of each clustered color, sorting them, for input to the fraction clustered color models
#wrap_fracColors: does fracColors and wraps for xgb prediction
#wrap_fracColors_only: assumes fracColor is already done and just puts in wrapper for xgb
def transform_images(t_type,data):
#NOTHING HERE IN MINIMAL VERSION
    return data

#loads an image from file
def load_img(imfile):
    #nothing her in minimal version
    #return np.asarray(img, dtype='int32')
    return None
    

def help():
    print("""
    Capstone Project Deliverable for Brandon Horan Springboard Machine Learning Engineering Carrer Track
    
    This project sought to model the Malaria Images dataset and determine whether an image of a cell was infected with malaria or not.  Included in this deliverable are a handful of models I developed which can be used to make predicions on images/data representing images.
    
    Available models to make predictions with:
    
    1. Number Colors: Logistic Regression, Decision Tree, XGBoost: 
        Input - Number of colors in an image

    2. Fraction Clustered Colors: Logistic Regression, Random Forest, XGBoost
        Input - Sorted Fraction of 7 cluster KMeans colors in each image
        
        
    How to use this deliverable:
        -Models may be loaded into memory using 'load_model'
        -Images may be loaded into memory using 'load_images'
        -Images may be transformed to model inputs using 'transform_images'
        -Predictions may be made on loaded images using 'predict'

    m_type legal values:
    'logistic regression'
    'decision tree'
        """)
