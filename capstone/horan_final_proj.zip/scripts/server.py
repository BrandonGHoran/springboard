import os
from flask import Flask, jsonify, request

import numpy as np

import json
import model_deploy_version as models

HEADERS = {'Content-type': 'application/json', 'Accept': 'text/plain'}

def flask_app():
    app = Flask(__name__)

    @app.route('/',methods=['GET'])
    def server_is_up():
        return 'server is up'

    @app.route('/predict',methods=['POST'])
    def start():
        to_predict = request.json

        #load parameters for model prediction
        m_type = to_predict['m_type']

        data = np.array(to_predict['data']) if 'clust' in m_type else to_predict['data']
        if 'clust' not in m_type and m_type != 'transfer' and to_predict['load'] == "False":
            data = data.reshape(-1,1)

        try:
            transform = bool(to_predict['transform'])
        except:
            transform = True
        try:
            load = bool(to_predict['load'])
        except:
            load = False
        print(data)
        #make and return prediction
        pred = models.predict(m_type, data, transform=transform, load=load)
        return str(pred)#jsonify({'predict lr':pred})

    return app

if __name__ == '__main__':
    app = flask_app()
    app.run(debug=True,host='0.0.0.0', port=8080)
