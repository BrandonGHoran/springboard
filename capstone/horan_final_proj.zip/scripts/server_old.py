import os
from flask import Flask, jsonify, request

import numpy as np

import json
import model_deploy_version_MINIMAL as models

HEADERS = {'Content-type': 'application/json', 'Accept': 'text/plain'}

def flask_app():
    app = Flask(__name__)

    @app.route('/',methods=['GET'])
    def server_is_up():
        return 'server is up'

    @app.route('/predict_lr',methods=['POST'])
    def start():
        to_predict = request.json

        pred = models.predict('logistic regression', np.array(to_predict['nColors']).reshape(-1,1), transform=False)
        return str(pred)#jsonify({'predict lr':pred})

    @app.route('/predict_tree',methods=['POST'])
    def go():
        to_predict = request.json
        pred = models.predict('decision tree',np.array(to_predict['nColors']).reshape(-1,1), transform=False)
        return str(pred)

    @app.route('/predict_xgb', methods=['POST'])
    def do_xgb():
        to_predict = request.json
        pred = models.predict('xgboost',np.array(to_predict['nColors']).reshape(-1,1), transform=False)
        return str(pred)

    @app.route('/predict_lrClust')
    def do_lr_clust():
        to_predict = request.json
        pred = models.predict('lr clust', np.array(to_predict['fracColors']), transform=False)
        return str(pred)

    @app.route('/predict_rfClust')
    def do_rf_clust():
        to_predict = request.json
        pred = models.predict('rf clust', np.array(to_predict['fracColors']), transform=False)
        return str(pred)

    @app.route('/predict_xgbClust')
    def do_xgb

    return app

if __name__ == '__main__':
    app = flask_app()
    app.run(debug=True,host='0.0.0.0')
