#! /bin/bash
cd /scripts
python compileCython.py colorFracs_v4 colorFracs_v4.pyx
python server.py
