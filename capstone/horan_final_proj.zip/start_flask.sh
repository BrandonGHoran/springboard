#! /bin/bash
cd /scripts
python server.py
